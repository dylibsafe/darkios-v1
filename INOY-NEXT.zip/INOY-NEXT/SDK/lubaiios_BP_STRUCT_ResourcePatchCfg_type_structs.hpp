#pragma once

//    
// PUBGM 4.2.0 iOS
// 分享: - @lubaiios 
// 生成时间 2026年01月06日 16时15分17秒
namespace SDK
{
//---------------------By lubaiios @LBAsTool---------------------------
//Script Structs
//---------------------By lubaiios @LBAsTool---------------------------

// UserDefinedStruct BP_STRUCT_ResourcePatchCfg_type.BP_STRUCT_ResourcePatchCfg_type
// 0x0020
struct FBP_STRUCT_ResourcePatchCfg_type
{
	struct FString                                     Res_0_5336A20017C3AD3C6DD6CA9604AB86B3;                   // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Version_1_77115100133C471835D454DB02BD35DE;               // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

