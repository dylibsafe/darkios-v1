#pragma once

//    
// PUBGM 4.2.0 iOS
// 分享: - @lubaiios 
// 生成时间 2026年01月06日 16时15分14秒
#include "../SDK.hpp"

namespace SDK
{
//---------------------By lubaiios @LBAsTool---------------------------
//Parameters
//---------------------By lubaiios @LBAsTool---------------------------

// Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadEffectItemBPTable
struct ULoadedClassManager_BP_C_LoadEffectItemBPTable_Params
{
	struct FString                                     BPTableName;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
};

// Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadBPTableData
struct ULoadedClassManager_BP_C_LoadBPTableData_Params
{
	struct FString                                     BPTableName;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
	struct FString                                     tableName;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
};

// Function LoadedClassManager_BP.LoadedClassManager_BP_C.Load3DIconBPTable
struct ULoadedClassManager_BP_C_Load3DIconBPTable_Params
{
	struct FString                                     BPTableName;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
};

// Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadInFillingBPTable
struct ULoadedClassManager_BP_C_LoadInFillingBPTable_Params
{
	struct FString                                     BPTableName;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
};

// Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadVehiclePropsBPTable
struct ULoadedClassManager_BP_C_LoadVehiclePropsBPTable_Params
{
	struct FString                                     BPTableName;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
};

// Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadDecalBPTable
struct ULoadedClassManager_BP_C_LoadDecalBPTable_Params
{
	struct FString                                     BPTableName;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
};

// Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadSkillPropsBPTable
struct ULoadedClassManager_BP_C_LoadSkillPropsBPTable_Params
{
	struct FString                                     BPTableName;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
};

// Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadPetAvatarBPTable
struct ULoadedClassManager_BP_C_LoadPetAvatarBPTable_Params
{
	struct FString                                     BPTableName;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
};

// Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadVehilceRefitBPTable
struct ULoadedClassManager_BP_C_LoadVehilceRefitBPTable_Params
{
	struct FString                                     BPTableName;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
};

// Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadSeasonMissionBPTable
struct ULoadedClassManager_BP_C_LoadSeasonMissionBPTable_Params
{
	struct FString                                     BPTableName;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
};

// Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadAvatarPatternBPTable
struct ULoadedClassManager_BP_C_LoadAvatarPatternBPTable_Params
{
	struct FString                                     BPTableName;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
};

// Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadAvatarColorBPTable
struct ULoadedClassManager_BP_C_LoadAvatarColorBPTable_Params
{
	struct FString                                     BPTableName;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
};

// Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadVehicleBPTable
struct ULoadedClassManager_BP_C_LoadVehicleBPTable_Params
{
	struct FString                                     BPTableName;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
};

// Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadPlaneBPTable
struct ULoadedClassManager_BP_C_LoadPlaneBPTable_Params
{
	struct FString                                     BPTableName;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
};

// Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadEmoteBPTable
struct ULoadedClassManager_BP_C_LoadEmoteBPTable_Params
{
	struct FString                                     BPTableName;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
};

// Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadConsumableBPTable
struct ULoadedClassManager_BP_C_LoadConsumableBPTable_Params
{
	struct FString                                     BPTableName;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
};

// Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadGameModeBPTable
struct ULoadedClassManager_BP_C_LoadGameModeBPTable_Params
{
	struct FString                                     BPTableName;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
};

// Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadAvatarBPTable
struct ULoadedClassManager_BP_C_LoadAvatarBPTable_Params
{
	struct FString                                     BPTableName;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
};

// Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadWeaponBPTable
struct ULoadedClassManager_BP_C_LoadWeaponBPTable_Params
{
	struct FString                                     BPTableName;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
};

// Function LoadedClassManager_BP.LoadedClassManager_BP_C.InitBPTableMap
struct ULoadedClassManager_BP_C_InitBPTableMap_Params
{
};

// Function LoadedClassManager_BP.LoadedClassManager_BP_C.InitBPTableMap_Mod
struct ULoadedClassManager_BP_C_InitBPTableMap_Mod_Params
{
};

// Function LoadedClassManager_BP.LoadedClassManager_BP_C.ExecuteUbergraph_LoadedClassManager_BP
struct ULoadedClassManager_BP_C_ExecuteUbergraph_LoadedClassManager_BP_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

