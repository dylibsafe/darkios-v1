#pragma once

//    
// PUBGM 4.2.0 iOS
// 分享: - @lubaiios 
// 生成时间 2026年01月06日 16时15分18秒
namespace SDK
{
//---------------------By lubaiios @LBAsTool---------------------------
//Script Structs
//---------------------By lubaiios @LBAsTool---------------------------

// UserDefinedStruct BP_STRUCT_WeaponSkinMapping_type.BP_STRUCT_WeaponSkinMapping_type
// 0x0038
struct FBP_STRUCT_WeaponSkinMapping_type
{
	struct FString                                     OutputDesc_0_4C755C4055DE81011AC086EE07D9D3D3;            // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                SkinID_1_6AF5A0C03E8D665F2B8E33D5019212C4;                // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                WeaponID_2_1D11360041F2AB4A2B54AC9608775314;              // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     URL_3_276895001829BC3265405AC70F011B5C;                   // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     iconURL_4_1C201F405280621B7F9C0B550EBB3B4C;               // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

